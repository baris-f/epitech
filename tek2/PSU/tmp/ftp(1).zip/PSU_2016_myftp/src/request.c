/*
** request.c for myftp in /home/duvalm/rendu/PSU_2016_myftp/src
**
** Made by Duval Lucas
** Login   <duval_m@epitech.net>
**
** Started on  Sun May 21 10:20:23 2017 Duval Lucas
** Last update Sun May 21 10:37:55 2017 Duval Lucas
*/

#include "function.h"

t_func cmdList[10] = {
  {"USER", &user},
  {"PASS", &pass},
  {"QUIT", &quit},
  {"NOOP", &noop},
  {"PWD", &pwd},
  {"CWD", &cwd},
  {"CDUP", &cdup},
  {"DELE", &delete},
  {"HELP", &help},
  {NULL, 0},
};

void request(struct_client *clt){
  int i = -1;
  int cmd = FALSE;
  xread(clt);
  while (cmdList[++i].cmd != NULL)
    if (strncmp(cmdList[i].cmd, clt->buff, strlen(cmdList[i].cmd)) == 0){
      cmdList[i].fct(clt);
      cmd = TRUE;
    }
  if (cmd == FALSE)
    xwrite(clt, "502 Command not implemented\r\n");
}
