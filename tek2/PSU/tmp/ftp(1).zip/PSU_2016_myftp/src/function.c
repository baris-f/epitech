/*
** function.c for myftp in /home/duvalm/rendu/PSU_2016_myftp/src
**
** Made by Duval Lucas
** Login   <duval_m@epitech.net>
**
** Started on  Sun May 21 10:20:16 2017 Duval Lucas
** Last update Sun May 21 10:45:34 2017 Duval Lucas
*/
#define _GNU_SOURCE

#include "function.h"

int	checkLogStatus(struct_client *clt)
{
  if (clt->isLogged != AUTH)
    {
      xwrite(clt, "530 Not loogged in.\r\n");
      return (TRUE);
    } else
    return (FALSE);
}

void	help(struct_client *clt)
{
  if (checkLogStatus(clt))
    return;
  xwrite(clt, "214 No help sry :/ \r\n");
}

void	user(struct_client *clt)
{
  if (strcasestr(clt->buff, "anonymous"))
    {
      clt->isLogged = LOGGED;
      xwrite(clt, "331 Please send password.\r\n");
    }
  else
    xwrite(clt, "332 Anonymous only.\r\n");
}

void	pass(struct_client *clt)
{
  if (clt->isLogged != LOGGED)
    {
      xwrite(clt, "332 Send USER first.\r\n");
    } else {
    clt->isLogged = AUTH;
    xwrite(clt, "230 Login ok.\r\n");
  }
}

void	cwd(struct_client *clt)
{
  char	wd[2018];
  char	*path;

  if (checkLogStatus(clt))
    return;
  path = buildPath(clt);
  if (path == NULL){
    printf("NULL\n");
    return ;
  }
  if (chdir(path) == -1) {
    xwrite(clt, "550 ");
    xwrite(clt, strerror(errno));
    xwrite(clt, "\r\n");
    free(path);
    return ;
  }
  bzero(wd, 2048);
  getcwd(wd, 2048);
  if (strlen(wd) < strlen(clt->path)) {
    chdir(clt->path);
    xwrite(clt, "550 Acces denied\r\n");
  } else
    xwrite(clt, "250 CWD command successful\r\n");
  free(path);
}
