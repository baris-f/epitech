/*
** xfunc.c for myftp in /home/duvalm/rendu/PSU_2016_myftp
**
** Made by Duval Lucas
** Login   <duval_m@epitech.net>
**
** Started on  Sun May 21 10:22:27 2017 Duval Lucas
** Last update Sun May 21 10:37:11 2017 Duval Lucas
*/

#include "function.h"

int	xread(struct_client *clt)
{
  int	r;
  int	i;

  bzero(clt->buff, 2048);
  if ((r = read(clt->sock, clt->buff, 2048)) <= 0)
    {
      clt->isConnected = FALSE;
      return (r);
    }
  for (i = 0; i < r; i++)
    if (clt->buff[i] == '\n' || clt->buff[i] == '\r')
      clt->buff[i] = '\0';
  return (r);
}

void	xwrite(struct_client *clt, char *msg)
{
  if (write(clt->sock, msg, strlen(msg)) == -1)
    clt->isConnected = FALSE;
}

void    error(char *s)
{
  perror(s);
  exit(1);
}
