//
// main.cpp for  in /home/fus/taff/ggj17/sfml/src
//
// Made by Gaspard Thirion
// Login   <thirio_b@epitech.net>
//
// Started on  Sat Jan 14 20:43:04 2017 Gaspard Thirion
// Last update Sat Jan 21 15:43:05 2017 baris_f
//

#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>

sf::ContextSettings contextSettings;
bool movingLeft, movingUp, movingRight, movingDown;
sf::CircleShape shape(50);
sf::RenderWindow window(sf::VideoMode(1600, 900), "sfml", sf::Style::Default, contextSettings);

void handlePlayerInput(sf::Keyboard::Key key, bool isPressed)
{
  if (key == sf::Keyboard::Up) movingUp = isPressed;
  else if (key == sf::Keyboard::Down) movingDown = isPressed;
  else if (key == sf::Keyboard::Left) movingLeft = isPressed;
  else if (key == sf::Keyboard::Right) movingRight = isPressed;
}

float speed = 50;

void update()
{
  sf::Vector2f movement(0.f, 0.f);
  if (movingUp) movement.y -= speed;
  if (movingDown) movement.y += speed;
  if (movingLeft) movement.x -= speed;
  if (movingRight) movement.x += speed;

  shape.move(movement);
}

int main()
{
  window.setVerticalSyncEnabled(false);
  window.setFramerateLimit(60);
  glEnable(GL_TEXTURE_2D);

  while (window.isOpen())
    {
      sf::Event event;
      while (window.pollEvent(event))
  	{
  	  if (event.type == sf::Event::Closed)
  	    window.close();
	  if (event.type == sf::Event::KeyPressed)
	    {
	      handlePlayerInput(event.key.code, true);
	      if (event.key.code == sf::Keyboard::Escape)
		window.close();
	    }
	  if (event.type == sf::Event::KeyReleased)
	    handlePlayerInput(event.key.code, false);
	}
      update();
      window.clear();
      window.draw(shape);
      window.display();
    }
  return (0);
}
